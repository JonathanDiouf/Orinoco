const getTeddies = async function(url) {
    let response = await fetch(url)
    let data = await response.json()
    return data
}
const teddy = getTeddies("http://localhost:3000/api/teddies");

const displayTeddies = async function() {
    const data = await teddy
    for (item of data) {
        for (let i = 0; i > data.length; i++) {
            let items_container = document.createElement('div');
            let container = document.getElementByClassName('.container');
            container.appendChild(items_container);
            console.log(container)
            while (items_container.childNodes.length < 3) {
                let newDiv = document.createElement('div');
                let newImg = document.createElement('img');
                let newDes = document.createElement('p');
                let newPri = document.createElement('p');
                let newName = document.createElement('p');
                newImg.src = item.imageUrl;
                newDes.innerText = String(item.description);
                newPri.innerText = item.price;
                newName.innerText = item.name;
                newDiv.appendChild(newImg);
                newDiv.appendChild(newDes);
                newDiv.appendChild(newPri);
                newDiv.appendChild(newName);
                newDiv.classList.add('item');
                newDiv.addEventListener('click', () => {
                    let id = item._id;
                    localStorage.setItem("id_select", id);
                    location.href = "./produit.html"
                })
                items_container.appendChild(newDiv);
                i++;
            }
        }
    }
}

displayTeddies()